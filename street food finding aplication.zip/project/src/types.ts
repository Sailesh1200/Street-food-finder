export interface Vendor {
  id: string;
  name: string;
  description: string;
  location: {
    latitude: number;
    longitude: number;
  };
  isOperational: boolean;
  signatureDishes: {
    name: string;
    price: number;
  }[];
  averageWaitTime: number;
  image: string;
  ownerId?: string;
  email?: string;
  phone?: string;
  businessHours?: {
    day: string;
    open: string;
    close: string;
  }[];
}

export interface UserLocation {
  latitude: number;
  longitude: number;
}

export interface VendorRegistration {
  email: string;
  password: string;
  vendorName: string;
  description: string;
  phone: string;
}