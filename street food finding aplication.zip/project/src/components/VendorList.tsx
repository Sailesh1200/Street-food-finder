import React from 'react';
import { Vendor, UserLocation } from '../types';
import { VendorCard } from './VendorCard';

interface VendorListProps {
  vendors: Vendor[];
  userLocation: UserLocation | null;
}

export function VendorList({ vendors, userLocation }: VendorListProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-6">
      {vendors.map((vendor) => (
        <VendorCard
          key={vendor.id}
          vendor={vendor}
          userLocation={userLocation}
        />
      ))}
    </div>
  );
}