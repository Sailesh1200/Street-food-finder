import React from 'react';
import { MapPin } from 'lucide-react';
import { Vendor, UserLocation } from '../types';

interface MapProps {
  vendors: Vendor[];
  userLocation: UserLocation | null;
  onVendorSelect: (vendor: Vendor) => void;
}

export function Map({ vendors, userLocation, onVendorSelect }: MapProps) {
  return (
    <div className="relative w-full h-[calc(100vh-4rem)] bg-gray-100 rounded-lg overflow-hidden">
      <div className="absolute inset-0 flex items-center justify-center">
        <p className="text-gray-500">Map integration coming soon...</p>
      </div>
      
      {/* Placeholder for vendor markers */}
      <div className="absolute bottom-4 right-4 space-y-2">
        {vendors.map(vendor => (
          <button
            key={vendor.id}
            onClick={() => onVendorSelect(vendor)}
            className="flex items-center space-x-2 bg-white px-3 py-2 rounded-lg shadow-md hover:shadow-lg transition-shadow"
          >
            <MapPin className="w-4 h-4 text-red-500" />
            <span className="text-sm font-medium">{vendor.name}</span>
          </button>
        ))}
      </div>
    </div>
  );
}