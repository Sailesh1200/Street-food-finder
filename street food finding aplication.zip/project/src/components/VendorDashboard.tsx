import React, { useState } from 'react';
import { Vendor } from '../types';
import { MapPin, Clock, DollarSign, Power, Plus, Trash } from 'lucide-react';

interface VendorDashboardProps {
  vendor: Vendor;
  onUpdate: (vendor: Vendor) => void;
}

export function VendorDashboard({ vendor, onUpdate }: VendorDashboardProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [editedVendor, setEditedVendor] = useState(vendor);
  const [newDish, setNewDish] = useState({ name: '', price: 0 });

  const handleSave = () => {
    onUpdate(editedVendor);
    setIsEditing(false);
  };

  const addDish = () => {
    if (newDish.name && newDish.price > 0) {
      setEditedVendor({
        ...editedVendor,
        signatureDishes: [...editedVendor.signatureDishes, newDish]
      });
      setNewDish({ name: '', price: 0 });
    }
  };

  const removeDish = (index: number) => {
    setEditedVendor({
      ...editedVendor,
      signatureDishes: editedVendor.signatureDishes.filter((_, i) => i !== index)
    });
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Vendor Dashboard</h2>
        <button
          onClick={() => setEditedVendor({
            ...editedVendor,
            isOperational: !editedVendor.isOperational
          })}
          className={`flex items-center px-4 py-2 rounded-md ${
            editedVendor.isOperational
              ? 'bg-green-100 text-green-800'
              : 'bg-red-100 text-red-800'
          }`}
        >
          <Power className="w-4 h-4 mr-2" />
          {editedVendor.isOperational ? 'Open' : 'Closed'}
        </button>
      </div>

      <div className="space-y-6">
        {isEditing ? (
          <>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Store Name
              </label>
              <input
                type="text"
                value={editedVendor.name}
                onChange={(e) => setEditedVendor({ ...editedVendor, name: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Description
              </label>
              <textarea
                value={editedVendor.description}
                onChange={(e) => setEditedVendor({ ...editedVendor, description: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
                rows={3}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Average Wait Time (minutes)
              </label>
              <input
                type="number"
                value={editedVendor.averageWaitTime}
                onChange={(e) => setEditedVendor({ ...editedVendor, averageWaitTime: parseInt(e.target.value) })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
              />
            </div>

            <div>
              <h3 className="text-lg font-medium mb-2">Signature Dishes</h3>
              <div className="space-y-2">
                {editedVendor.signatureDishes.map((dish, index) => (
                  <div key={index} className="flex items-center gap-2">
                    <input
                      type="text"
                      value={dish.name}
                      onChange={(e) => {
                        const newDishes = [...editedVendor.signatureDishes];
                        newDishes[index].name = e.target.value;
                        setEditedVendor({ ...editedVendor, signatureDishes: newDishes });
                      }}
                      className="flex-1 px-3 py-2 border border-gray-300 rounded-md"
                    />
                    <input
                      type="number"
                      value={dish.price}
                      onChange={(e) => {
                        const newDishes = [...editedVendor.signatureDishes];
                        newDishes[index].price = parseFloat(e.target.value);
                        setEditedVendor({ ...editedVendor, signatureDishes: newDishes });
                      }}
                      className="w-24 px-3 py-2 border border-gray-300 rounded-md"
                    />
                    <button
                      onClick={() => removeDish(index)}
                      className="p-2 text-red-600 hover:bg-red-50 rounded-md"
                    >
                      <Trash className="w-4 h-4" />
                    </button>
                  </div>
                ))}
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={newDish.name}
                    onChange={(e) => setNewDish({ ...newDish, name: e.target.value })}
                    placeholder="New dish name"
                    className="flex-1 px-3 py-2 border border-gray-300 rounded-md"
                  />
                  <input
                    type="number"
                    value={newDish.price}
                    onChange={(e) => setNewDish({ ...newDish, price: parseFloat(e.target.value) })}
                    placeholder="Price"
                    className="w-24 px-3 py-2 border border-gray-300 rounded-md"
                  />
                  <button
                    onClick={addDish}
                    className="p-2 text-green-600 hover:bg-green-50 rounded-md"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </>
        ) : (
          <>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <h3 className="text-sm font-medium text-gray-500">Location</h3>
                <p className="flex items-center mt-1">
                  <MapPin className="w-4 h-4 mr-2 text-gray-400" />
                  {editedVendor.location.latitude.toFixed(4)}, {editedVendor.location.longitude.toFixed(4)}
                </p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-gray-500">Wait Time</h3>
                <p className="flex items-center mt-1">
                  <Clock className="w-4 h-4 mr-2 text-gray-400" />
                  {editedVendor.averageWaitTime} minutes
                </p>
              </div>
            </div>

            <div>
              <h3 className="text-sm font-medium text-gray-500 mb-2">Signature Dishes</h3>
              <div className="space-y-2">
                {editedVendor.signatureDishes.map((dish, index) => (
                  <div key={index} className="flex justify-between items-center">
                    <span>{dish.name}</span>
                    <span className="flex items-center text-gray-600">
                      <DollarSign className="w-4 h-4 mr-1" />
                      {dish.price.toFixed(2)}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}

        <div className="flex justify-end gap-4 pt-4">
          {isEditing ? (
            <>
              <button
                onClick={() => {
                  setEditedVendor(vendor);
                  setIsEditing(false);
                }}
                className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={handleSave}
                className="px-4 py-2 bg-gray-900 text-white rounded-md hover:bg-gray-800"
              >
                Save Changes
              </button>
            </>
          ) : (
            <button
              onClick={() => setIsEditing(true)}
              className="px-4 py-2 bg-gray-900 text-white rounded-md hover:bg-gray-800"
            >
              Edit Store
            </button>
          )}
        </div>
      </div>
    </div>
  );
}