import React from 'react';
import { Clock, DollarSign, MapPin } from 'lucide-react';
import { Vendor } from '../types';
import { calculateDistance } from '../utils/distance';

interface VendorCardProps {
  vendor: Vendor;
  userLocation: { latitude: number; longitude: number } | null;
}

export function VendorCard({ vendor, userLocation }: VendorCardProps) {
  const distance = userLocation
    ? calculateDistance(
        userLocation.latitude,
        userLocation.longitude,
        vendor.location.latitude,
        vendor.location.longitude
      )
    : null;

  const averagePrice =
    vendor.signatureDishes.reduce((acc, dish) => acc + dish.price, 0) /
    vendor.signatureDishes.length;

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <img
        src={vendor.image}
        alt={vendor.name}
        className="w-full h-48 object-cover"
      />
      <div className="p-4">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-lg font-semibold">{vendor.name}</h3>
          <span
            className={`px-2 py-1 rounded-full text-sm ${
              vendor.isOperational
                ? 'bg-green-100 text-green-800'
                : 'bg-red-100 text-red-800'
            }`}
          >
            {vendor.isOperational ? 'Open' : 'Closed'}
          </span>
        </div>
        
        <p className="text-gray-600 mb-4">{vendor.description}</p>

        <div className="space-y-2">
          {distance && (
            <div className="flex items-center text-gray-600">
              <MapPin className="w-4 h-4 mr-2" />
              <span>{distance.toFixed(1)} km away</span>
            </div>
          )}
          
          <div className="flex items-center text-gray-600">
            <Clock className="w-4 h-4 mr-2" />
            <span>~{vendor.averageWaitTime} min wait</span>
          </div>

          <div className="flex items-center text-gray-600">
            <DollarSign className="w-4 h-4 mr-2" />
            <span>Average price: ${averagePrice.toFixed(2)}</span>
          </div>
        </div>

        <div className="mt-4">
          <h4 className="font-medium mb-2">Signature Dishes:</h4>
          <div className="space-y-1">
            {vendor.signatureDishes.map((dish) => (
              <div
                key={dish.name}
                className="flex justify-between text-sm text-gray-600"
              >
                <span>{dish.name}</span>
                <span>${dish.price.toFixed(2)}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}