import React, { useState, useEffect } from 'react';
import { Map } from './components/Map';
import { VendorList } from './components/VendorList';
import { SearchBox } from './components/SearchBox';
import { VendorRegistration } from './components/VendorRegistration';
import { VendorDashboard } from './components/VendorDashboard';
import { Vendor, UserLocation, VendorRegistration as VendorRegistrationType } from './types';
import { MapPin, List, Store } from 'lucide-react';

// Mock data for demonstration
const mockVendors: Vendor[] = [
  {
    id: '1',
    name: 'Taco Delight',
    description: 'Authentic Mexican street tacos with homemade salsas',
    location: { latitude: 34.0522, longitude: -118.2437 },
    isOperational: true,
    signatureDishes: [
      { name: 'Al Pastor Taco', price: 3.50 },
      { name: 'Carne Asada Taco', price: 3.75 },
      { name: 'Birria Taco', price: 4.00 }
    ],
    averageWaitTime: 10,
    image: 'https://images.unsplash.com/photo-1565299585323-38d6b0865b47?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '2',
    name: 'Dim Sum Express',
    description: 'Traditional dim sum served from a mobile cart',
    location: { latitude: 34.0505, longitude: -118.2400 },
    isOperational: true,
    signatureDishes: [
      { name: 'Siu Mai', price: 5.00 },
      { name: 'Har Gow', price: 5.50 },
      { name: 'BBQ Pork Buns', price: 4.50 }
    ],
    averageWaitTime: 15,
    image: 'https://images.unsplash.com/photo-1563245372-f21724e3856d?auto=format&fit=crop&w=800&q=80'
  }
];

function App() {
  const [vendors, setVendors] = useState<Vendor[]>(mockVendors);
  const [userLocation, setUserLocation] = useState<UserLocation | null>(null);
  const [selectedVendor, setSelectedVendor] = useState<Vendor | null>(null);
  const [viewMode, setViewMode] = useState<'map' | 'list'>('map');
  const [searchQuery, setSearchQuery] = useState('');
  const [showRegistration, setShowRegistration] = useState(false);
  const [currentVendor, setCurrentVendor] = useState<Vendor | null>(null); // For logged-in vendor

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setUserLocation({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
          });
        },
        (error) => {
          console.error('Error getting location:', error);
        }
      );
    }
  }, []);

  const handleVendorRegistration = (data: VendorRegistrationType) => {
    // In a real app, this would make an API call to create the vendor account
    const newVendor: Vendor = {
      id: String(vendors.length + 1),
      name: data.vendorName,
      description: data.description,
      location: userLocation || { latitude: 0, longitude: 0 },
      isOperational: true,
      signatureDishes: [],
      averageWaitTime: 0,
      image: 'https://images.unsplash.com/photo-1565299585323-38d6b0865b47?auto=format&fit=crop&w=800&q=80',
      email: data.email,
      phone: data.phone
    };

    setVendors([...vendors, newVendor]);
    setCurrentVendor(newVendor);
    setShowRegistration(false);
  };

  const handleVendorUpdate = (updatedVendor: Vendor) => {
    setVendors(vendors.map(v => v.id === updatedVendor.id ? updatedVendor : v));
    setCurrentVendor(updatedVendor);
  };

  const filteredVendors = vendors.filter(vendor => {
    const searchLower = searchQuery.toLowerCase();
    return (
      vendor.name.toLowerCase().includes(searchLower) ||
      vendor.description.toLowerCase().includes(searchLower) ||
      vendor.signatureDishes.some(dish => 
        dish.name.toLowerCase().includes(searchLower)
      )
    );
  });

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col py-4 space-y-4">
            <div className="flex justify-between items-center">
              <h1 className="text-2xl font-bold text-gray-900">Street Food Finder</h1>
              <div className="flex space-x-4">
                {!currentVendor && (
                  <button
                    onClick={() => setShowRegistration(true)}
                    className="flex items-center px-4 py-2 rounded-md bg-gray-900 text-white hover:bg-gray-800"
                  >
                    <Store className="w-5 h-5 mr-2" />
                    Register Store
                  </button>
                )}
                <button
                  onClick={() => setViewMode('map')}
                  className={`flex items-center px-3 py-2 rounded-md ${
                    viewMode === 'map'
                      ? 'bg-gray-900 text-white'
                      : 'text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  <MapPin className="w-5 h-5 mr-2" />
                  Map
                </button>
                <button
                  onClick={() => setViewMode('list')}
                  className={`flex items-center px-3 py-2 rounded-md ${
                    viewMode === 'list'
                      ? 'bg-gray-900 text-white'
                      : 'text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  <List className="w-5 h-5 mr-2" />
                  List
                </button>
              </div>
            </div>
            <SearchBox 
              vendors={vendors}
              onSearch={setSearchQuery}
            />
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {currentVendor ? (
          <VendorDashboard
            vendor={currentVendor}
            onUpdate={handleVendorUpdate}
          />
        ) : (
          viewMode === 'map' ? (
            <Map
              vendors={filteredVendors}
              userLocation={userLocation}
              onVendorSelect={setSelectedVendor}
            />
          ) : (
            <VendorList
              vendors={filteredVendors}
              userLocation={userLocation}
            />
          )
        )}
      </main>

      {showRegistration && (
        <VendorRegistration
          onSubmit={handleVendorRegistration}
          onClose={() => setShowRegistration(false)}
        />
      )}
    </div>
  );
}

export default App;